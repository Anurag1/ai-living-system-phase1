
from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
import asyncio, json
from utils.messages import make_msg
from organs.language import LanguageOrgan
from organs.vision import VisionOrgan
from organs.speech import SpeechOrgan
from organs.knowledge import KnowledgeOrgan
from organs.memory import MemoryOrgan
from organs.image_gen import ImageGenOrgan
from organs.tts import TTSOrgan
from organs.hidden_gen import GlobalHiddenGenerativeLayer
from coordinator.orchestrator import Orchestrator

app = FastAPI(title="AI Living System Dashboard")

language = LanguageOrgan()
vision = VisionOrgan()
speech = SpeechOrgan()
knowledge = KnowledgeOrgan()
memory = MemoryOrgan()
image_gen = ImageGenOrgan()
tts = TTSOrgan()
hidden = GlobalHiddenGenerativeLayer()

organs = {
    "language": language,
    "vision": vision,
    "speech": speech,
    "knowledge": knowledge,
    "memory": memory,
    "image_gen": image_gen,
    "tts": tts
}
orchestrator = Orchestrator(organs, hidden, memory)

@app.get("/")
async def index():
    return HTMLResponse("""
    <!DOCTYPE html>
    <html>
    <head>
        <title>AI Living System Dashboard</title>
        <style>
            body { font-family: Arial, sans-serif; padding: 1em; }
            .msg { border-bottom: 1px solid #ddd; padding: 0.5em 0; }
            .hidden { color: #777; }
        </style>
    </head>
    <body>
        <h2>AI Living System Dashboard</h2>
        <input id="input" type="text" size="50" placeholder="Type a message..." />
        <button onclick="send()">Send</button>
        <div id="messages"></div>
        <script>
            let ws = new WebSocket("ws://" + location.host + "/ws");
            ws.onmessage = function(event) {
                let msg = JSON.parse(event.data);
                let div = document.createElement("div");
                div.className = "msg" + (msg.hidden ? " hidden" : "");
                div.innerText = msg.source + " → " + msg.payload.type + ": " + msg.payload.content;
                document.getElementById("messages").prepend(div);
            };
            function send() {
                let text = document.getElementById("input").value;
                ws.send(text);
                document.getElementById("input").value = "";
            }
        </script>
    </body>
    </html>
    """)

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    while True:
        try:
            data = await ws.receive_text()
            user_msg = make_msg("user", "text", data)
            outputs = await orchestrator.run_mesh(user_msg)
            for o in outputs:
                await ws.send_text(json.dumps(o))
        except Exception as e:
            await ws.send_text(json.dumps({"error": str(e)}))
