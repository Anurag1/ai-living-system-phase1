
from sentence_transformers import SentenceTransformer
import numpy as np
_MODEL = SentenceTransformer("all-MiniLM-L6-v2")
def embed(texts):
    if isinstance(texts, str):
        texts = [texts]
    vecs = _MODEL.encode(texts, convert_to_numpy=True)
    return vecs
def cosine_sim(a,b):
    a = a/(np.linalg.norm(a)+1e-12)
    b = b/(np.linalg.norm(b)+1e-12)
    return float(np.dot(a,b))
