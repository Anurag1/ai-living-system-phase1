
import uuid, time
from typing import Dict, Any

def make_msg(source: str, payload_type: str, content: str, confidence: float = 0.9, provenance: Dict[str,Any]=None, hidden: bool=False):
    return {
        "id": str(uuid.uuid4()),
        "timestamp": time.time(),
        "source": source,
        "payload": {"type": payload_type, "content": content},
        "confidence": confidence,
        "provenance": provenance or {"model": source},
        "hidden": hidden
    }
