
import asyncio
from utils.embeddings import embed, cosine_sim
from config import Config

class Orchestrator:
    def __init__(self, organs: dict, hidden_layer, memory):
        self.organs = organs
        self.hidden = hidden_layer
        self.memory = memory
        self.max_layers = Config.MAX_LAYERS
        self.prune_k = Config.PRUNE_K
        self.conv_sim = Config.CONVERGENCE_SIM

    async def _call(self, func, *args, **kwargs):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, func, *args, **kwargs)

    async def process_single_msg(self, msg):
        outputs = []
        tasks = [self._call(organ.process, msg) for organ in self.organs.values()]
        res = await asyncio.gather(*tasks)
        outputs.extend([r for r in res if r is not None])
        hidden = []
        for organ in self.organs.values():
            if hasattr(organ, 'hidden_generate'):
                hidden.extend(organ.hidden_generate(msg, n=1))
        outputs.extend(hidden)
        global_hidden = []
        for o in outputs:
            global_hidden.extend(self.hidden.generate(o, n_variations=1))
        outputs.extend(global_hidden)
        for o in outputs:
            try:
                self.memory.process(o)
            except Exception:
                pass
        return outputs

    async def run_mesh(self, user_msg):
        current = [user_msg]
        all_outputs = []
        for layer in range(self.max_layers):
            next_msgs = []
            for m in current:
                outs = await self.process_single_msg(m)
                next_msgs.extend(outs)
                all_outputs.extend(outs)
            next_msgs = self.prune(next_msgs)
            if self.check_convergence(next_msgs):
                print(f'[Orchestrator] Converged at layer {layer+1}')
                break
            current = next_msgs
        return all_outputs

    def prune(self, msgs):
        by_src = {}
        for m in msgs:
            by_src.setdefault(m['source'], []).append(m)
        pruned = []
        for src, items in by_src.items():
            items_sorted = sorted(items, key=lambda x: x.get('confidence',0.0), reverse=True)
            pruned.extend(items_sorted[:self.prune_k])
        return pruned

    def check_convergence(self, msgs):
        texts = [m['payload']['content'] for m in msgs if not m.get('hidden',False)]
        if len(texts) < 2:
            return False
        emb = embed(texts)
        import numpy as np
        sims = []
        for i in range(len(emb)):
            for j in range(i+1, len(emb)):
                sims.append(cosine_sim(emb[i], emb[j]))
        avg = float(np.mean(sims)) if sims else 0.0
        print(f'[Orchestrator] avg sim: {avg:.3f}')
        return avg > self.conv_sim
