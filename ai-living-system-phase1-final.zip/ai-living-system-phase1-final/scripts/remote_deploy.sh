
#!/usr/bin/env bash
set -euo pipefail
cd ~/ai-living-system || mkdir -p ~/ai-living-system && cd ~/ai-living-system
docker-compose pull || true
docker-compose up -d --remove-orphans
docker image prune -f || true
echo "Deployed successfully at $(date) on $(hostname)"
