
import asyncio
from utils.messages import make_msg
from config import Config
from organs.language import LanguageOrgan
from organs.vision import VisionOrgan
from organs.speech import SpeechOrgan
from organs.knowledge import KnowledgeOrgan
from organs.memory import MemoryOrgan
from organs.image_gen import ImageGenOrgan
from organs.tts import TTSOrgan
from organs.hidden_gen import GlobalHiddenGenerativeLayer
from coordinator.orchestrator import Orchestrator

async def main():
    language = LanguageOrgan()
    vision = VisionOrgan()
    speech = SpeechOrgan()
    knowledge = KnowledgeOrgan()
    memory = MemoryOrgan()
    image_gen = ImageGenOrgan()
    tts = TTSOrgan()
    hidden = GlobalHiddenGenerativeLayer()
    organs = {
        'language': language,
        'vision': vision,
        'speech': speech,
        'knowledge': knowledge,
        'memory': memory,
        'image_gen': image_gen,
        'tts': tts
    }
    orchestrator = Orchestrator(organs, hidden, memory)
    user_msg = make_msg('user','text','Explain quantum entanglement simply and show a diagram')
    outputs = await orchestrator.run_mesh(user_msg)
    print('\n=== Non-hidden outputs ===\n')
    for o in outputs:
        if not o.get('hidden', False):
            print(f"{o['source']} | {o['payload']['type']} | {o['payload']['content']}")
if __name__ == '__main__':
    asyncio.run(main())
