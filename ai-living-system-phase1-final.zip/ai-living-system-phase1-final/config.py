
from dotenv import load_dotenv
import os
load_dotenv()

class Config:
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
    HUGGINGFACE_TOKEN = os.getenv('HUGGINGFACEHUB_API_TOKEN')
    WOLFRAM_APP_ID = os.getenv('WOLFRAM_APP_ID')
    PINECONE_API_KEY = os.getenv('PINECONE_API_KEY')
    PINECONE_ENV = os.getenv('PINECONE_ENV')
    ELEVENLABS_API_KEY = os.getenv('ELEVENLABS_API_KEY')
    HF_LLM = os.getenv('HF_LLM', 'google/flan-t5-large')
    BLIP_MODEL = os.getenv('BLIP_MODEL', 'Salesforce/blip-image-captioning-base')
    SD_MODEL = os.getenv('SD_MODEL', 'runwayml/stable-diffusion-v1-5')
    EMB_MODEL = os.getenv('EMB_MODEL', 'sentence-transformers/all-MiniLM-L6-v2')
    MAX_LAYERS = int(os.getenv('MAX_LAYERS', '3'))
    PRUNE_K = int(os.getenv('PRUNE_K', '4'))
    CONVERGENCE_SIM = float(os.getenv('CONVERGENCE_SIM', '0.9'))
