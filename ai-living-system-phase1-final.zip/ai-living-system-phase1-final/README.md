
# 🧠 AI Living System – Phase 1 (Final Production Bundle)

This repository assembles a production-ready Phase 1 of the AI Living System:
- Real-model organs (Language, Vision, Speech, Knowledge, Memory, ImageGen, TTS)
- Per-organ hidden generators + Global Hidden Generative Layer
- Orchestrator/coordinator (async)
- FastAPI dashboard (WebSocket) for live visualization
- Dockerfile + docker-compose for containerized deployment
- Kubernetes manifests + GitHub Actions for auto-deploy to k8s
- Demo notebook and examples

## Quickstart (local)

1. Copy `.env.example` → `.env` and fill API keys (OpenAI, HuggingFace, Wolfram, Pinecone, ElevenLabs) as needed.
2. Create and activate virtualenv:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. Run CLI demo:
   ```bash
   python main.py
   ```
4. Run dashboard:
   ```bash
   uvicorn dashboard.app:app --reload --port 8000
   ```
   Open http://127.0.0.1:8000

## Docker
Build & run:
```bash
docker-compose build
docker-compose up
```

## Kubernetes
1. Add `KUBECONFIG` secret to GitHub (base64-encoded kubeconfig)
2. Push to `main` — GitHub Action will build image and update deployment.
3. Apply manifests if first deploy:
```bash
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/ingress.yaml  # optional
```

## Notes
- GPU recommended for BLIP-2 and Stable Diffusion.
- If API keys are missing the system will attempt local fallbacks where available.
- Outputs (images, audio) are saved in `outputs/`.
