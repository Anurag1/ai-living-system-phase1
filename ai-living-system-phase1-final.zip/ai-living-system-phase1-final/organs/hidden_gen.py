
from utils.messages import make_msg
from organs.language import LanguageOrgan
from organs.image_gen import ImageGenOrgan
class GlobalHiddenGenerativeLayer:
    name = 'global_hidden'
    def __init__(self):
        self.lang = LanguageOrgan()
        self.img = ImageGenOrgan()
    def generate(self, msg, n_variations=1):
        text = msg['payload']['content']
        outs = []
        for i in range(n_variations):
            h = self.lang.hidden_generate(msg, n=1)[0]
            outs.append(make_msg(self.name, 'gen_text', h['payload']['content'], confidence=0.7, hidden=True, provenance={'model':'global_text_gen'}))
            hi = self.img.hidden_generate(msg, n=1)[0]
            outs.append(make_msg(self.name, 'gen_image_prompt', hi['payload']['content'], confidence=0.65, hidden=True, provenance={'model':'global_img_gen'}))
        return outs
