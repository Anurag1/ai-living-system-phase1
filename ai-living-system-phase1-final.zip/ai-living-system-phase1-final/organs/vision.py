
from utils.messages import make_msg
from config import Config
from transformers import BlipProcessor, BlipForConditionalGeneration
from PIL import Image
import requests
class VisionOrgan:
    name = 'vision'
    def __init__(self):
        self.processor = BlipProcessor.from_pretrained(Config.BLIP_MODEL)
        self.model = BlipForConditionalGeneration.from_pretrained(Config.BLIP_MODEL)
    def process(self, msg):
        text = msg['payload']['content']
        if text.startswith('http://') or text.startswith('https://'):
            try:
                image = Image.open(requests.get(text, stream=True).raw).convert('RGB')
                inputs = self.processor(image, return_tensors='pt')
                out = self.model.generate(**inputs)
                caption = self.processor.decode(out[0], skip_special_tokens=True)
                return make_msg(self.name, 'caption', caption, confidence=0.9, provenance={'model': Config.BLIP_MODEL})
            except Exception as e:
                return make_msg(self.name, 'error', f'Could not fetch/process image: {e}', confidence=0.4)
        else:
            caption = f'Vision conceptual caption for "{text[:120]}"'
            return make_msg(self.name, 'caption', caption, confidence=0.85)
    def hidden_generate(self, msg, n=1):
        text = msg['payload']['content']
        return [make_msg(self.name, 'hidden_caption', f'Alt vision {i+1} for "{text[:30]}"', confidence=0.6, hidden=True) for i in range(n)]
