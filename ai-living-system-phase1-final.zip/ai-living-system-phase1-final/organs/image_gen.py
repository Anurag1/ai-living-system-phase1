
from utils.messages import make_msg
from config import Config
from diffusers import StableDiffusionPipeline
import torch, os
class ImageGenOrgan:
    name = 'image_gen'
    def __init__(self):
        model_id = Config.SD_MODEL
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        self.pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16 if device=='cuda' else torch.float32)
        self.pipe = self.pipe.to(device)
    def process(self, msg):
        prompt = msg['payload']['content']
        image = self.pipe(prompt, num_inference_steps=20).images[0]
        out_path = f'outputs/img_{msg["id"][:8]}.png'
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        image.save(out_path)
        return make_msg(self.name, 'image', out_path, confidence=0.9, provenance={'model': Config.SD_MODEL})
    def hidden_generate(self, msg, n=1):
        prompt = msg['payload']['content']
        return [make_msg(self.name, 'hidden_image', f'{prompt} style {i+1}', confidence=0.6, hidden=True) for i in range(n)]
