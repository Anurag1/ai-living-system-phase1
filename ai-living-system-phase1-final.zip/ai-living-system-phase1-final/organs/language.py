
import os
from utils.messages import make_msg
from config import Config
if Config.OPENAI_API_KEY:
    import openai
    openai.api_key = Config.OPENAI_API_KEY
from transformers import pipeline
_llm_pipe = None
def _init_hf():
    global _llm_pipe
    if _llm_pipe is None:
        _llm_pipe = pipeline('text2text-generation', model=Config.HF_LLM)
class LanguageOrgan:
    name = 'language'
    def __init__(self):
        if not Config.OPENAI_API_KEY:
            _init_hf()
    def process(self, msg):
        text = msg['payload']['content']
        if Config.OPENAI_API_KEY:
            resp = openai.ChatCompletion.create(model='gpt-4', messages=[{'role':'user','content':text}], temperature=0.2)
            out = resp['choices'][0]['message']['content']
            prov = {'model':'openai-gpt4'}
        else:
            out = _llm_pipe(f"Explain simply: {text}", max_length=256)[0]['generated_text']
            prov = {'model': Config.HF_LLM}
        return make_msg(self.name, 'explanation', out, confidence=0.95, provenance=prov)
    def hidden_generate(self, msg, n=2):
        text = msg['payload']['content']
        outs = []
        for i in range(n):
            prompt = f"Paraphrase {i+1}: {text}"
            if Config.OPENAI_API_KEY:
                resp = openai.ChatCompletion.create(model='gpt-4', messages=[{'role':'user','content':prompt}], temperature=0.7)
                out = resp['choices'][0]['message']['content']
            else:
                out = _llm_pipe(prompt, max_length=160)[0]['generated_text']
            outs.append(make_msg(self.name, 'hidden_text', out, confidence=0.7, hidden=True))
        return outs
