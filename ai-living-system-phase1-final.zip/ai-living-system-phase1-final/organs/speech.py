
from utils.messages import make_msg
from config import Config
try:
    from faster_whisper import WhisperModel
except Exception:
    WhisperModel = None
class SpeechOrgan:
    name = 'speech'
    def __init__(self):
        if WhisperModel is None:
            raise RuntimeError('faster-whisper not installed')
        self.model = WhisperModel('small')
    def process(self, msg):
        path = msg['payload']['content']
        result = self.model.transcribe(path)
        text = result['text'] if isinstance(result, dict) and 'text' in result else str(result)
        return make_msg(self.name, 'transcript', text, confidence=0.95, provenance={'model':'faster-whisper'})
    def hidden_generate(self, msg, n=1):
        text = msg['payload']['content']
        return [make_msg(self.name, 'hidden_transcript', f'{text} (variant {i+1})', confidence=0.6, hidden=True) for i in range(n)]
