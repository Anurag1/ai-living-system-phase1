
from utils.messages import make_msg
from config import Config
import pyttsx3, os, requests
class TTSOrgan:
    name = 'tts'
    def __init__(self):
        self.engine = pyttsx3.init()
    def process(self, msg):
        text = msg['payload']['content']
        if Config.ELEVENLABS_API_KEY:
            url = 'https://api.elevenlabs.io/v1/text-to-speech/default'
            headers = {'xi-api-key': Config.ELEVENLABS_API_KEY, 'Content-Type':'application/json'}
            data = {'text': text}
            r = requests.post(url, headers=headers, json=data)
            if r.status_code==200:
                out_path = f'outputs/tts_{msg["id"][:8]}.mp3'
                with open(out_path,'wb') as f: f.write(r.content)
                return make_msg(self.name, 'tts', out_path, confidence=0.95, provenance={'model':'elevenlabs'})
        out_path = f'outputs/tts_{msg["id"][:8]}.wav'
        os.makedirs(os.path.dirname(out_path), exist_ok=True)
        self.engine.save_to_file(text, out_path)
        self.engine.runAndWait()
        return make_msg(self.name, 'tts', out_path, confidence=0.85, provenance={'model':'pyttsx3'})
    def hidden_generate(self, msg, n=1):
        text = msg['payload']['content']
        return [make_msg(self.name, 'hidden_tts', f'{text} voice {i+1}', confidence=0.6, hidden=True) for i in range(n)]
