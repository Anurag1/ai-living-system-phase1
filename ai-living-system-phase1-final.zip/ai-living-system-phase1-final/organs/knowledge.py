
from utils.messages import make_msg
from config import Config
import wikipedia
try:
    import wolframalpha
except Exception:
    wolframalpha = None
class KnowledgeOrgan:
    name = 'knowledge'
    def __init__(self):
        self.wa = None
        if Config.WOLFRAM_APP_ID and wolframalpha:
            try:
                self.wa = wolframalpha.Client(Config.WOLFRAM_APP_ID)
            except Exception:
                self.wa = None
    def process(self, msg):
        q = msg['payload']['content']
        if self.wa:
            try:
                res = self.wa.query(q)
                ans = next(res.results).text
                return make_msg(self.name, 'wolfram', ans, confidence=0.95, provenance={'model':'wolfram'})
            except Exception:
                pass
        try:
            title = wikipedia.search(q, results=1)
            if title:
                summary = wikipedia.summary(title[0], sentences=2)
                return make_msg(self.name, 'wiki', summary, confidence=0.9, provenance={'model':'wikipedia'})
        except Exception:
            pass
        return make_msg(self.name, 'no_result', 'No result', confidence=0.5)
    def hidden_generate(self, msg, n=1):
        q = msg['payload']['content']
        return [make_msg(self.name, 'hidden_knowledge', f'Hypothesis {i+1} for "{q[:30]}"', confidence=0.6, hidden=True) for i in range(n)]
