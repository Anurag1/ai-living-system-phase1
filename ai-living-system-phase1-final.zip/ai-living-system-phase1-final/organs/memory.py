
from utils.messages import make_msg
from config import Config
from utils.embeddings import embed
import os, pickle
try:
    import pinecone
except Exception:
    pinecone = None
class MemoryOrgan:
    name = 'memory'
    def __init__(self, index_path='memory.pkl'):
        self.index_path = index_path
        self.store = []
        self.vectors = []
        self.pine = None
        if Config.PINECONE_API_KEY and pinecone:
            pinecone.init(api_key=Config.PINECONE_API_KEY, environment=Config.PINECONE_ENV)
            self.pine = pinecone.Index('ai-mesh') if 'ai-mesh' in pinecone.list_indexes() else pinecone.create_index('ai-mesh', dimension=384)
        if os.path.exists(self.index_path):
            with open(self.index_path,'rb') as f:
                data = pickle.load(f)
                self.store = data.get('store',[])
                self.vectors = data.get('vectors',[])
    def process(self, msg):
        text = msg['payload']['content']
        vec = embed(text)[0].astype('float32')
        self.store.append(msg)
        self.vectors.append(vec)
        if self.pine:
            self.pine.upsert([(msg['id'], vec.tolist(), {'content': text})])
            return make_msg(self.name, 'stored', 'stored in pinecone', confidence=0.9, provenance={'model':'pinecone'})
        else:
            with open(self.index_path,'wb') as f:
                pickle.dump({'store': self.store, 'vectors': self.vectors}, f)
            return make_msg(self.name, 'stored', 'stored locally', confidence=0.85)
    def hidden_generate(self, msg, n=1):
        text = msg['payload']['content']
        return [make_msg(self.name, 'hidden_memory', f'Imputed {i+1} for "{text[:30]}"', confidence=0.6, hidden=True) for i in range(n)]
